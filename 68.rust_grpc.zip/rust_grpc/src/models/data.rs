use serde::{Deserialize,Serialize};
#[derive(Deserialize,Serialize,Debug)]
pub struct DataDevice{
    #[serde(skip_deserializing)]
    pub id:i32,
    pub device:String,
    pub status:bool,
    pub date:String,
}
impl DataDevice{
    pub fn new()->Self{
        DataDevice {
            id:0,
            device:"".to_string(),
            status:false,
            date: "".to_string(),
        }
    }
}
