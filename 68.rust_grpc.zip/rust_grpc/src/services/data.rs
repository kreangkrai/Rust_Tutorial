use tokio;
use crate::database::db::DB;
use tokio_postgres::{NoTls};
use crate::models::DataDevice;
use chrono::{DateTime,Local};

pub async fn getbydevice(_device:String)->Result<DataDevice,tokio_postgres::Error>{
    let (client,connection) = tokio_postgres::connect(DB::url().url,NoTls).await?;
    tokio::spawn(async move{
        if let Err(e) = connection.await{
            eprintln!("connection error : {}",e);
        }
    });
    let mut datas = DataDevice::new();
    let mut device:String;
    let mut status:bool;
    let mut date:DateTime<Local>;

    let rows = client.query("select * from devices where device = $1", &[&_device]).await?;
    for row in rows{
        device = row.get(1);
        status = row.get(2);
        date = row.get(3);

        datas.device = device;
        datas.date = date.format("%Y-%m-%d %H:%M:%S").to_string();
        datas.status = status;
    }
    Ok(datas)
}