use crate::models::{Point};
use std::ops::Add;
impl <T> Point<T>{
    pub fn new(x:T,y:T)->Self{
        Point{
            x:x,
            y:y,
        }
    }
}
impl <T:Add<Output = T>> Add for Point<T>{
    type Output = Point<T>;

    fn add(self,other:Self)-> Self::Output{
        Point{
            x:self.x + other.x,
            y:self.y + other.y,
        }
    }
}