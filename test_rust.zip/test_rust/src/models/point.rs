#[derive(Debug)]
pub struct Point<T>{
    pub x:T,
    pub y:T,
}